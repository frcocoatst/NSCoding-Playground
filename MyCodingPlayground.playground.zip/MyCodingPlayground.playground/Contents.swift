//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

class Element: NSObject, NSCoding {
    var number:                     Int                     // reference number
    var type:                       Int                     // type = [BUBBLE|TERMINATOR|STORE|RECT]
    var name:                       String                  // name string
    var descr:                      String                  // description string
    // layout data
    var location:                   NSPoint                 // central location of the element
    var number_connectionPoint:     Int                     // actual number of connectionpoints
    var connectionPoints:           [NSPoint]               // [] array of connection points

    
    init(number:Int, type: Int, name :String, descr :String, location: NSPoint, number_connectionPoint :Int,
         connectionPoints :[NSPoint])
        {

        self.number = number
        self.type = type
        self.name = name
        self.descr = descr
        // layout data
        self.location = location
        self.number_connectionPoint = number_connectionPoint
        self.connectionPoints = connectionPoints
    }
    
    // MARK: NSCoding
    required convenience init(coder decoder: NSCoder) {
        let number = decoder.decodeIntegerForKey("number")
        let type = decoder.decodeIntegerForKey("type")
        let name = decoder.decodeObjectForKey("name") as! String
        let descr = decoder.decodeObjectForKey("descr") as! String
        let location = decoder.decodePointForKey("location") 
        let number_connectionPoint = decoder.decodeIntegerForKey("number_connectionPoint")
        // let connectionPoints = decoder.decodeObjectForKey("connectionPoints") as! [NSPoint] // replaced by
        let connectionPoints = (decoder.decodeObjectForKey("connectionPoints") as! [NSValue]).map { $0.pointValue }
        
        self.init(number: number, type :type, name :name, descr :descr, location: location,
                  number_connectionPoint :number_connectionPoint, connectionPoints :connectionPoints )
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeInt(Int32(self.number), forKey: "number")
        coder.encodeInt(Int32(self.type), forKey: "type")
        coder.encodeObject(self.name, forKey: "name")
        coder.encodeObject(self.descr, forKey: "descr")
        coder.encodePoint(self.location, forKey: "location")
        coder.encodeInt(Int32(self.number_connectionPoint), forKey: "number_connectionPoint")
        // coder.encodeObject(connectionPoints, forKey: "connectionPoints") not working so:
        // http://stackoverflow.com/questions/34166213/how-to-encode-an-array-of-cgpoints-with-nscoder-in-swift
        let connectionPointsValues = connectionPoints.map { NSValue(point:$0) }
        coder.encodeObject(connectionPointsValues, forKey: "connectionPoints")
    }
}

// create element
// ==================
var p: NSPoint = NSMakePoint(10.0, 100.0)      // default element
var q: NSPoint = NSMakePoint(51.0, 52.0)
var pointarray:  [NSPoint] = [p,p,p,p,p,p,p,p,q]   //
var pointarray2: [NSPoint] = [q,p,q,p,q,p,q,p,q]


let element = Element(
                number: 1, type :2, name :"Der Name", descr :"Die Beschreibung", location: NSMakePoint(10.0, 100.0),
                number_connectionPoint :20, connectionPoints :pointarray
)

// Archive and unarchive element
//
let filePath = "/tmp/element.bin"
NSKeyedArchiver.archiveRootObject(element, toFile: filePath)

if let elementData = NSKeyedUnarchiver.unarchiveObjectWithFile( "/tmp/element.bin") as? Element {
        print("elementData:")
        print("number   = \(elementData.number)")
        print("type     = \(elementData.type)")
        print("name     = \(elementData.name)")
        print("descr    = \(elementData.descr)")
        print("location = \(elementData.location)")
        print("nr_cPnts = \(elementData.number_connectionPoint)")
        print("conPoints=\(elementData.connectionPoints)")
}

// create elements array
// ======================

let elements = [Element( number: 1, type :2, name :"Der Name", descr :"Die Beschreibung", location: NSMakePoint(10.0, 100.0),
                         number_connectionPoint :20, connectionPoints :pointarray),
                Element( number: 2, type :3, name :"Zweiter", descr :"Zweite Beschreibung", location: NSMakePoint(5.0, 90.0),
                         number_connectionPoint :12, connectionPoints :pointarray),
                Element( number: 3, type :5, name :"Dritter", descr :"Dritte Beschreibung", location: NSMakePoint(75.0, 11.0),
                         number_connectionPoint :36, connectionPoints :pointarray2)]

// Archive and unarchive elements
//
let filePathA = "/tmp/elements.bin"
NSKeyedArchiver.archiveRootObject(elements, toFile: filePathA)

if let elementsArray = NSKeyedUnarchiver.unarchiveObjectWithFile(filePathA) as? [Element] {
    /*
     print("elementsArray[0]:")
     print("number   = \(elementsArray[0].number)")
     print("type     = \(elementsArray[0].type)")
     print("name     = \(elementsArray[0].name)")
     print("descr    = \(elementsArray[0].descr)")
     print("location = \(elementsArray[0].location)")
     print("nr_cPnts = \(elementsArray[0].number_connectionPoint)")
     print("conPoints= \(elementsArray[0].connectionPoints)")
     */

    for i in 0..<elementsArray.count{
        print("elementsArray[\(i)]:")
        print("number   = \(elementsArray[i].number)")
        print("type     = \(elementsArray[i].type)")
        print("name     = \(elementsArray[i].name)")
        print("descr    = \(elementsArray[i].descr)")
        print("location = \(elementsArray[i].location)")
        print("nr_cPnts = \(elementsArray[i].number_connectionPoint)")
        print("conPoints= \(elementsArray[i].connectionPoints)")
    }
}

// -----
print()
print("Other Example")
print()
// ------
// http://stackoverflow.com/questions/34166213/how-to-encode-an-array-of-cgpoints-with-nscoder-in-swift
let positions = [NSMakePoint(1, 1), NSMakePoint(1, 2)]
let spawns    = [NSMakePoint(2, 1), NSMakePoint(2, 2)]

// Encode
let positionValues = positions.map { NSValue(point:$0) }
let spawnValues    = spawns.map    { NSValue(point:$0) }

let data = NSMutableData()
let archiver = NSKeyedArchiver(forWritingWithMutableData: data)
archiver.encodeObject(positionValues, forKey: "positions")
archiver.encodeObject(spawnValues, forKey: "spawns")
archiver.finishEncoding()

// Decode:
let unarchiver = NSKeyedUnarchiver(forReadingWithData: data)
let x = (unarchiver.decodeObjectForKey("positions") as! [NSValue]).map { $0.pointValue }
let y = (unarchiver.decodeObjectForKey("spawns")    as! [NSValue]).map { $0.pointValue }

print("positions = \(positions), x = \(x)")
print("spawns    = \(spawns), y = \(y)")
